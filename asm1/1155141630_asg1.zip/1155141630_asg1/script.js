/**
* CSCI2720/ESTR2106 Assignment 1
* Bootstrap Web Page with a Web Form
*
* I declare that the assignment here submitted is original
* except for source material explicitly acknowledged,
* and that the same or closely related material has not been
* previously submitted for another course.
* I also acknowledge that I am aware of University policy and
* regulations on honesty in academic work, and of the disciplinary
* guidelines and procedures applicable to breaches of such
* policy and regulations, as contained in the website.
*
* University Guideline on Academic Honesty:
*   http://www.cuhk.edu.hk/policy/academichonesty
* Faculty of Engineering Guidelines to Academic Honesty:
*   https://www.erg.cuhk.edu.hk/erg/AcademicHonesty
*
* Student Name: YU Sihong
* Student ID  : 1155141630
* Date        : 2022/10/04
*/
fetch('comments.txt')
    .then(function (res) { return res.text(); })
    .then(function (txt) {
    var newComment = document.createElement("div");
    newComment.innerHTML = txt;
    var obj = document.querySelector("#comments");
    obj.appendChild(newComment);
});
function showhidden(input) {
    var obj = document.getElementById('hiddenBar');
    if (obj.style.display === 'none') {
        obj.style.display = '';
    }
    else {
        obj.style.display = 'none';
    }
}
function task1(input) {
    location.href = "#sections";
    document.getElementsByName("sectionTitle").forEach(function (v, i) {
        if (v.classList.contains('text-start')) {
            v.classList.remove('text-start');
            v.classList.add('text-center');
        }
        else if (v.classList.contains('text-center')) {
            v.classList.remove('text-center');
            v.classList.add('text-end');
        }
        else if (v.classList.contains('text-end')) {
            v.classList.remove('text-end');
            v.classList.add('text-start');
        }
    });
}
function task2(input) {
    location.href = "#hobby";
    var hobby = window.prompt("What's your hobby?");
    var description;
    if (hobby) {
        description = window.prompt("Please briefly describe");
        if (description) {
            var newhob = document.createElement("tr");
            var element = '<td>' + hobby + '</td><td>' + description + '</td>';
            newhob.innerHTML = element;
            var obj = document.getElementById("hobbies");
            obj.appendChild(newhob);
        }
        else {
            window.alert("Enter nothing, disgarded.");
        }
    }
    else {
        window.alert("Enter nothing, disgarded.");
    }
}
function task3(input) {
    var obj = document.getElementById('progressBar');
    if (obj.style.display == 'none') {
        obj.style.display = '';
        document.addEventListener('scroll', function () {
            var scro = window.scrollY;
            var scrohei = document.documentElement.scrollHeight;
            var winhei = window.innerHeight;
            var num = (scro / (scrohei - winhei) * 100).toString();
            var progress = document.getElementById("progress");
            progress.style.width = num + '%';
        });
    }
    else {
        obj.style.display = 'none';
    }
}
/* <div class="card text-white bg-primary mt-3 ms-3 me-3"><div class="card-header">shyu0@qq.com</div><div class="card-body"><p class="card-text">What a great job!</p></div></div> */
function processform(input) {
    var objemai = document.querySelector("#new-email");
    var email = objemai.value;
    var objcomm = document.querySelector("#new-comment");
    var comment = objcomm.value;
    var color;
    if (email && email.match(/^\S+@\S+$/)) {
        objemai.classList.remove("is-invalid");
    }
    else {
        objemai.classList.add("is-invalid");
        return;
    }
    if (comment) {
        objcomm.classList.remove("is-invalid");
    }
    else {
        objcomm.classList.add("is-invalid");
        return;
    }
    var objcol = document.querySelectorAll("input[name=new-color]:checked");
    if (objcol.length == 1) {
        document.querySelectorAll(".form-check-input").forEach(function (v, i) {
            v.classList.remove("is-invalid");
        });
        color = objcol[0].value;
    }
    else {
        document.querySelectorAll(".form-check-input").forEach(function (v, i) {
            v.classList.add("is-invalid");
        });
        return;
    }
    var element = '<div class="card-header">' + email + '</div><div class="card-body"><p class="card-text">' + comment + '</p></div></div>';
    var newComment = document.createElement("div");
    newComment.innerHTML = element;
    newComment.classList.add('card', 'mt-3', 'ms-3', 'me-3');
    if (color) {
        newComment.classList.add(color);
    }
    var objcomms = document.querySelector("#comments");
    objcomms.appendChild(newComment);
    fetch('comments.txt')
        .then(function (res) { return res.text(); })
        .then(function (txt) {
        fetch('comments.txt', {
            method: 'PUT',
            body: txt + newComment.outerHTML
        });
    });
    var objfor = document.querySelector("form");
    objfor.reset();
}
